function [output_result] = SSFSCRD(input_matrix,win_in,win_out,order_in,beta,lambda)
%�������Ϸ�������Ҷ�任 ������ CRD�����������ڸú����ڲ���ɹ�һ��
%   2020.04.22
DataTest =input_matrix;
DataTest = DataTest./max(DataTest(:));
[rows cols bands] = size(DataTest);
M = rows * cols;

im1 = zeros(rows, cols, bands);
for i = 1:rows
    for j = 1:cols
        % amptitude
        im1(i,j,:) = Disfrft(squeeze(DataTest(i,j,:)),order);
    end
end

im1 = center_standard(abs(im1));

y=im1;
[a1,a2,a3]=size(y);

%window set
in=win_in;
out=win_out;
center=(out+1)/2;
outex=fix(out/2);
outw=ones(out,out);
for i=(out-in)/2+1:(out+in)/2
    for j=(out-in)/2+1:(out+in)/2
        outw(i,j)=0;
    end
end
inw=ones(in,in);
N=out^2-in^2;

for s=1:a3
    Y_ex(:,:,s)=padarray(y(:,:,s),[outex,outex],'symmetric');
end
% lambda=1;
alpha=zeros(a1,a2,N);
weight=zeros(N,N);
weight_new=zeros(N,1);
X_back=zeros(a3,N);
sal_map=zeros(a1,a2);
for i=1:a1
    for j=1:a2
     xt=reshape(y(i,j,:),a3,1);
     X_cur=Y_ex(i:i+out-1,j:j+out-1,:);  
     k=0;
     for m=1:out
         for n=1:out
             if(outw(m,n)==1)
               k=k+1;
               X_back(:,k)= X_cur(m,n,:);
               d_pos=sqrt((center-m)^2+(center-n)^2);
               weight_new(k,1)=norm(xt- X_back(:,k))/d_pos;
             end
         end
     end
     sal_map(i,j)=exp(sum(weight_new)/N);
     weight_d=diag(weight_new);
     alpha_new(i,j,:)=pinv((X_back'*X_back+lambda*(weight_d')*weight_d))*X_back'*xt;
    alpha1_new=reshape(alpha_new(i,j,:),N,1);
    r1(i,j)=norm(xt-X_back*alpha1_new);
    end
end


r_final =rsalientAdjust8(r1,beta,r1);

output_result=r_final;

end

