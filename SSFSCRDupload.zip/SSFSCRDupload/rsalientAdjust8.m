function [r_final] = rsalientAdjust8(r_matrix,beta,X_in)

[a1, a2] = size(r_matrix);
r_adjust=zeros(a1,a2);
X_in = X_in./max(X_in(:));
for  i=1:a1
    for j=1:a2
        if(i==1)
            if(j==1)
                %salient(X_in,row_num,col_num,center_r,center_c)
                % 1 2 3
                % 4 c 5
                %6 7 8
                s5=salient(X_in,i,j+1,i,j);
                s7=salient(X_in,i+1,j,i,j);                
                s8=salient(X_in,i+1,j+1,i,j);
                p5=s5/(s5+s7+s8);
                p7=s7/(s5+s7+s8);
                p8=s8/(s5+s7+s8);
                r_adjust(i,j)= p7*r_matrix(i+1,j)+p5*r_matrix(i,j+1)+p8*r_matrix(i+1,j+1);
                %r_adjust(i,j)=r_adjust(i,j)/3;
            elseif(j==a2)
                s4=salient(X_in,i,j-1,i,j); 
                s6=salient(X_in,i+1,j-1,i,j); 
                s7=salient(X_in,i+1,j,i,j);
                p4=s4/(s4+s6+s7);
                p6=s6/(s4+s6+s7);
                p7=s7/(s4+s6+s7);
                r_adjust(i,j)= p7*r_matrix(i+1,j)+p4*r_matrix(i,j-1)+p6*r_matrix(i+1,j-1);
                 %r_adjust(i,j)=r_adjust(i,j)/3;
            else
                s4=salient(X_in,i,j-1,i,j); 
                s5=salient(X_in,i,j+1,i,j);
                s6=salient(X_in,i+1,j-1,i,j); 
                s7=salient(X_in,i+1,j,i,j); 
                s8=salient(X_in,i+1,j+1,i,j);
                p4=s4/(s4+s5+s6+s7+s8);
                p5=s5/(s4+s5+s6+s7+s8);
                p6=s6/(s4+s5+s6+s7+s8);
                p7=s7/(s4+s5+s6+s7+s8);
                p8=s8/(s4+s5+s6+s7+s8);
                r_adjust(i,j)= p7*r_matrix(i+1,j)+p4*r_matrix(i,j-1)+p5*r_matrix(i,j+1)+p6*r_matrix(i+1,j-1)+p8*r_matrix(i+1,j+1); 
               % r_adjust(i,j)=r_adjust(i,j)/5;
            end
        elseif(i==a1)
             if(j==1)
                s2=salient(X_in,i-1,j,i,j);
                s3=salient(X_in,i-1,j+1,i,j);
                s5=salient(X_in,i,j+1,i,j);
                p2=s2/(s2+s3+s5);
                p3=s3/(s2+s3+s5);
                p5=s5/(s2+s3+s5);
                r_adjust(i,j)= p2*r_matrix(i-1,j)+p5*r_matrix(i,j+1)+p3*r_matrix(i-1,j+1);
                %r_adjust(i,j)=r_adjust(i,j)/3;
            elseif(j==a2)
                s1=salient(X_in,i-1,j-1,i,j); 
                s2=salient(X_in,i-1,j,i,j);
                s4=salient(X_in,i,j-1,i,j); 
                p1=s1/(s1+s2+s4);
                p2=s2/(s1+s2+s4);
                p4=s4/(s1+s2+s4);
                r_adjust(i,j)= p2*r_matrix(i-1,j)+p4*r_matrix(i,j-1)+p1*r_matrix(i-1,j-1);
                 %r_adjust(i,j)=r_adjust(i,j)/3;
             else
                s1=salient(X_in,i-1,j-1,i,j);
                s2=salient(X_in,i-1,j,i,j);
                s3=salient(X_in,i-1,j+1,i,j);
                s4=salient(X_in,i,j-1,i,j);
                s5=salient(X_in,i,j+1,i,j);
                p1=s1/(s1+s2+s3+s4+s5);
                p2=s2/(s1+s2+s3+s4+s5);
                p3=s3/(s1+s2+s3+s4+s5);
                p4=s4/(s1+s2+s3+s4+s5);
                p5=s5/(s1+s2+s3+s4+s5);
                r_adjust(i,j)= p2*r_matrix(i-1,j)+p4*r_matrix(i,j-1)+p5*r_matrix(i,j+1)+p3*r_matrix(i-1,j+1)+p1*r_matrix(i-1,j-1); 
                 %  r_adjust(i,j)=r_adjust(i,j)/5;
            end
        else
             if(j==1)
               s2=salient(X_in,i-1,j,i,j);
               s3=salient(X_in,i-1,j+1,i,j);
               s5=salient(X_in,i,j+1,i,j);
               s7=salient(X_in,i+1,j,i,j); 
               s8=salient(X_in,i+1,j+1,i,j);
               p2=s2/(s2+s3+s5+s7+s8);
               p3=s3/(s2+s3+s5+s7+s8);
               p5=s5/(s2+s3+s5+s7+s8);
               p7=s7/(s2+s3+s5+s7+s8);
               p8=s8/(s2+s3+s5+s7+s8);
               r_adjust(i,j)= p2*r_matrix(i-1,j)+p7*r_matrix(i+1,j)+p5*r_matrix(i,j+1)+p8*r_matrix(i+1,j+1)+p3*r_matrix(i-1,j+1);
               % r_adjust(i,j)=r_adjust(i,j)/5;
            elseif(j==a2)
                 s1=salient(X_in,i-1,j-1,i,j);
                s2=salient(X_in,i-1,j,i,j);
                s4=salient(X_in,i,j-1,i,j);
                s6=salient(X_in,i+1,j-1,i,j); 
                s7=salient(X_in,i+1,j,i,j); 
                p1=s1/(s1+s2+s4+s6+s7);
                p2=s2/(s1+s2+s4+s6+s7);
                p4=s4/(s1+s2+s4+s6+s7);
                p6=s6/(s1+s2+s4+s6+s7);
                p7=s7/(s1+s2+s4+s6+s7);
                r_adjust(i,j)= p2*r_matrix(i-1,j)+p7*r_matrix(i+1,j)+p4*r_matrix(i,j-1)+p1*r_matrix(i-1,j-1)+p6*r_matrix(i+1,j-1);
                 %r_adjust(i,j)=r_adjust(i,j)/5;
             else
                s1=salient(X_in,i-1,j-1,i,j);
                s2=salient(X_in,i-1,j,i,j);
                s3=salient(X_in,i-1,j+1,i,j);
                s4=salient(X_in,i,j-1,i,j);
                s5=salient(X_in,i,j+1,i,j);
                s6=salient(X_in,i+1,j-1,i,j); 
                s7=salient(X_in,i+1,j,i,j); 
                s8=salient(X_in,i+1,j+1,i,j);
                p1=s1/(s1+s2+s3+s4+s5+s6+s7+s8);
                p2=s2/(s1+s2+s3+s4+s5+s6+s7+s8);
                p3=s3/(s1+s2+s3+s4+s5+s6+s7+s8);
                p4=s4/(s1+s2+s3+s4+s5+s6+s7+s8);
                p5=s5/(s1+s2+s3+s4+s5+s6+s7+s8);
                p6=s6/(s1+s2+s3+s4+s5+s6+s7+s8);
                p7=s7/(s1+s2+s3+s4+s5+s6+s7+s8);
                p8=s8/(s1+s2+s3+s4+s5+s6+s7+s8);
                r_adjust(i,j)=  p2*r_matrix(i-1,j)+p7*r_matrix(i+1,j)+p4*r_matrix(i,j-1)+p5*r_matrix(i,j+1)+p1*r_matrix(i-1,j-1)+p3*r_matrix(i-1,j+1)+p6*r_matrix(i+1,j-1)+p8*r_matrix(i+1,j+1);
                  %r_adjust(i,j)=r_adjust(i,j)/8;
             end          
        end
     end    
end
%r_final=zeros(a1,a2);
r_final=beta*r_matrix+(1-beta)*r_adjust;
end

function [s_result] = salient(X_in,row_num,col_num,center_r,center_c)
 d_pos=sqrt((center_r-row_num)^2+(center_c-col_num)^2);
 [rows cols bands] = size(X_in);
 X_cen=reshape(X_in(center_r,center_c,:),bands,1);
 X_adj=reshape(X_in(row_num,col_num,:),bands,1);
 s_result=exp(1/(d_pos+norm(X_cen-X_adj)));
end

